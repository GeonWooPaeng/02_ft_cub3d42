/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing_check.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gpaeng <gpaeng@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/05/20 19:21:26 by gpaeng            #+#    #+#             */
/*   Updated: 2021/05/22 18:25:26 by gpaeng           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/ft_cub3d.h"

void	ft_map_check(t_all *all)
{
	int		row;
	int		col;
	char	p;

	col = 0;
	while (col < all->map.height)
	{
		row = 0;
		while (row < all->map.width)
		{
			p = all->map.tab[col][row];
			if (p != '1' && col == 0)
				ft_error("[Error] map error");
			else if (p != '1' && col == all->map.height - 1)
				ft_error("[Error] map error");
			else if (p != '1' && row == 0)
				ft_error("[Error] map error");
			else if (p != '1' && row == all->map.width - 1)
				ft_error("[Error] map error");
			row += 1;
		}
		col += 1;
	}
}

void	ft_player_check(t_all *all)
{
	int		row;
	int		col;
	char	p;

	col = 0;
	while (col < all->map.height)
	{
		row = 0;
		while (row < all->map.width)
		{
			p = all->map.tab[col][row];
			if (all->player.player_num > 1)
				ft_error("[Error] check player number");
			if (p == 'N' || p == 'E' || p == 'S' || p == 'W')
				all->player.player_num += 1;
			row += 1;
		}
		col += 1;
	}
}

int		ft_name_check(char *a, char *b)
{
	int	idx;

	idx = 0;
	while (a[idx] != '\0')
		idx++;
	if ((idx > 4 && a[idx - 4] == b[0] && a[idx - 3] == b[1]
	&& a[idx - 2] == b[2] && a[idx - 1] == b[3]))
		return (1);
	return (0);
}

int		ft_name_check2(char *a, char *b)
{
	int	idx;

	idx = 0;
	while (a[idx] == b[idx])
	{
		if (a[idx] == '\0' && b[idx] == '\0')
			return (1);
		idx++;
	}
	return (0);
}

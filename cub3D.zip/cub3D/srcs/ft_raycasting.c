/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_raycasting.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gpaeng <gpaeng@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/23 19:58:04 by gpaeng            #+#    #+#             */
/*   Updated: 2021/05/17 23:07:08 by gpaeng           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_cub3d.h"

void	ft_side_dist(t_all *all)
{
	if (all->ray.dir_x < 0)
	{
		all->ray.step_x = -1;
		all->ray.side_dist_x = (all->player.x - all->map.x)
		* all->ray.delta_dist_x;
	}
	else
	{
		all->ray.step_x = 1;
		all->ray.side_dist_x = (all->map.x + 1.0 - all->player.x)
		* all->ray.delta_dist_x;
	}
	if (all->ray.dir_y < 0)
	{
		all->ray.step_y = -1;
		all->ray.side_dist_y = (all->player.y - all->map.y)
		* all->ray.delta_dist_y;
	}
	else
	{
		all->ray.step_y = 1;
		all->ray.side_dist_y = (all->map.y + 1.0
				- all->player.y) * all->ray.delta_dist_y;
	}
}

void	ft_hit_side(t_all *all)
{
	while (all->hit.h == 0)
	{
		if (all->ray.side_dist_x < all->ray.side_dist_y)
		{
			all->ray.side_dist_x += all->ray.delta_dist_x;
			all->map.x += all->ray.step_x;
			all->hit.side = (all->ray.step_x == -1) ? 1 : 0;
		}
		else
		{
			all->ray.side_dist_y += all->ray.delta_dist_x;
			all->map.y += all->ray.step_y;
			all->hit.side = (all->ray.step_y == -1) ? 3 : 2;
		}
		if (all->map.tab[all->map.y][all->map.x] == '1')
			all->hit.h = 1;
	}
}

void	ft_wall_dist(t_all *all)
{
	if (all->hit.side <= 1)
		all->ray.perp_wall_dist = (all->map.x - all->player.x
		+ (1 - all->ray.step_x) / 2) / all->ray.dir_x;
	else
		all->ray.perp_wall_dist = (all->map.y - all->player.y
		+ (1 - all->ray.step_y) / 2) / all->ray.dir_y;
}

void	ft_wall_height(t_all *all)
{
	all->ray.line_height = (int)(all->info.win_y / all->ray.perp_wall_dist);
	all->ray.draw_start = -all->ray.line_height / 2 + all->info.win_y / 2;
	all->ray.draw_end = all->ray.line_height / 2 + all->info.win_y / 2;
	if (all->ray.draw_start < 0)
		all->ray.draw_start = 0;
	if (all->ray.draw_end >= all->info.win_y)
		all->ray.draw_end = all->info.win_y - 1;
}

void	ft_raycasting(t_all *all)
{
	int x;

	ft_up_bottom(all);
	x = 0;
	while (x < all->info.win_x)
	{
		ft_init_ray(all, x);
		ft_side_dist(all);
		ft_hit_side(all);
		ft_wall_dist(all);
		ft_wall_height(all);
		ft_wall_texture(all);
		ft_wall_color(all, x);
		all->tex.zbuf[x] = all->ray.perp_wall_dist;
		x++;
	}
}
